// hi
export default () => {
    console.log('front js')
}
